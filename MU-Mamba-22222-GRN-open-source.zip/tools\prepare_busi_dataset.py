from __future__ import annotations

import argparse
import json
import random
import shutil
from pathlib import Path
from typing import Dict, List

import numpy as np
from PIL import Image


IMAGE_SUFFIXES = {'.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff'}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description='Prepare Dataset_BUSI_with_GT into train/val/test images+masks directories.'
    )
    parser.add_argument('--input-dir', type=Path, required=True, help='Path to Dataset_BUSI_with_GT root.')
    parser.add_argument('--output-dir', type=Path, required=True, help='Output dataset root.')
    parser.add_argument('--train-ratio', type=float, default=0.8)
    parser.add_argument('--val-ratio', type=float, default=0.1)
    parser.add_argument('--test-ratio', type=float, default=0.1)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--overwrite', action='store_true', help='Delete output-dir if it already exists.')
    return parser.parse_args()


def validate_ratios(train_ratio: float, val_ratio: float, test_ratio: float) -> None:
    total = train_ratio + val_ratio + test_ratio
    if abs(total - 1.0) > 1e-6:
        raise ValueError(f'ratios must sum to 1.0, got {total:.6f}')
    if min(train_ratio, val_ratio, test_ratio) <= 0:
        raise ValueError('all split ratios must be positive')


def ensure_clean_dir(path: Path, overwrite: bool) -> None:
    if path.exists():
        if not overwrite:
            raise FileExistsError(f'output directory already exists: {path}')
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def sample_id(class_name: str, stem: str) -> str:
    return f'{class_name}__{stem}'


def collect_samples(input_dir: Path) -> List[Dict[str, object]]:
    if not input_dir.exists():
        raise FileNotFoundError(f'input directory does not exist: {input_dir}')

    samples: List[Dict[str, object]] = []
    for class_dir in sorted(path for path in input_dir.iterdir() if path.is_dir()):
        for image_path in sorted(class_dir.iterdir()):
            if not image_path.is_file() or image_path.suffix.lower() not in IMAGE_SUFFIXES:
                continue
            if '_mask' in image_path.stem.lower():
                continue
            mask_paths = sorted(class_dir.glob(f'{image_path.stem}_mask*.png'))
            if not mask_paths:
                raise FileNotFoundError(f'no masks found for image: {image_path}')
            samples.append(
                {
                    'id': sample_id(class_dir.name, image_path.stem),
                    'class_name': class_dir.name,
                    'image_path': image_path,
                    'mask_paths': mask_paths,
                }
            )

    if not samples:
        raise ValueError(f'no BUSI image/mask pairs found under {input_dir}')
    return samples


def split_classwise(
    samples: List[Dict[str, object]],
    train_ratio: float,
    val_ratio: float,
    seed: int,
) -> Dict[str, List[Dict[str, object]]]:
    grouped: Dict[str, List[Dict[str, object]]] = {}
    for sample in samples:
        grouped.setdefault(str(sample['class_name']), []).append(sample)

    split_map = {'train': [], 'val': [], 'test': []}
    rng = random.Random(seed)
    for class_name, class_samples in sorted(grouped.items()):
        class_samples = list(class_samples)
        rng.shuffle(class_samples)
        total = len(class_samples)
        train_count = int(total * train_ratio)
        val_count = int(total * val_ratio)
        test_count = total - train_count - val_count
        if min(train_count, val_count, test_count) <= 0:
            raise ValueError(
                f'class {class_name} split counts must all be positive, '
                f'got train={train_count}, val={val_count}, test={test_count}'
            )
        split_map['train'].extend(class_samples[:train_count])
        split_map['val'].extend(class_samples[train_count:train_count + val_count])
        split_map['test'].extend(class_samples[train_count + val_count:])
    return split_map


def merge_masks(mask_paths: List[Path]) -> Image.Image:
    merged = None
    for mask_path in mask_paths:
        mask = np.asarray(Image.open(mask_path).convert('L'), dtype=np.uint8) > 0
        merged = mask if merged is None else np.logical_or(merged, mask)
    return Image.fromarray((merged.astype(np.uint8) * 255), mode='L')


def save_split(output_dir: Path, split_name: str, samples: List[Dict[str, object]]) -> Dict[str, object]:
    images_dir = output_dir / split_name / 'images'
    masks_dir = output_dir / split_name / 'masks'
    images_dir.mkdir(parents=True, exist_ok=True)
    masks_dir.mkdir(parents=True, exist_ok=True)

    class_counts: Dict[str, int] = {}
    ids: List[str] = []
    for sample in sorted(samples, key=lambda item: str(item['id'])):
        image_path = Path(str(sample['image_path']))
        mask_paths = list(sample['mask_paths'])
        class_name = str(sample['class_name'])
        sid = str(sample['id'])
        ids.append(sid)
        class_counts[class_name] = class_counts.get(class_name, 0) + 1

        image = Image.open(image_path).convert('RGB')
        mask = merge_masks(mask_paths)
        image.save(images_dir / f'{sid}.png')
        mask.save(masks_dir / f'{sid}.png')

    return {'count': len(samples), 'class_counts': class_counts, 'ids': ids}


def main() -> None:
    args = parse_args()
    validate_ratios(args.train_ratio, args.val_ratio, args.test_ratio)
    ensure_clean_dir(args.output_dir, overwrite=args.overwrite)

    samples = collect_samples(args.input_dir)
    split_map = split_classwise(
        samples=samples,
        train_ratio=args.train_ratio,
        val_ratio=args.val_ratio,
        seed=args.seed,
    )

    summary = {
        'input_dir': str(args.input_dir),
        'output_dir': str(args.output_dir),
        'seed': int(args.seed),
        'ratios': {
            'train': float(args.train_ratio),
            'val': float(args.val_ratio),
            'test': float(args.test_ratio),
        },
        'total_samples': len(samples),
        'splits': {},
    }

    for split_name in ('train', 'val', 'test'):
        summary['splits'][split_name] = save_split(args.output_dir, split_name, split_map[split_name])

    summary_path = args.output_dir / 'split_summary.json'
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
