from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
OUT_PATH = ROOT / "outputs" / "ours_model_diagram.png"


def load_font(size: int, bold: bool = False):
    candidates = []
    if bold:
        candidates.extend(
            [
                "C:/Windows/Fonts/arialbd.ttf",
                "C:/Windows/Fonts/calibrib.ttf",
                "C:/Windows/Fonts/segoeuib.ttf",
            ]
        )
    candidates.extend(
        [
            "C:/Windows/Fonts/arial.ttf",
            "C:/Windows/Fonts/calibri.ttf",
            "C:/Windows/Fonts/segoeui.ttf",
        ]
    )
    for path in candidates:
        try:
            return ImageFont.truetype(path, size=size)
        except OSError:
            continue
    return ImageFont.load_default()


FONT_SM = load_font(20)
FONT_MD = load_font(26)
FONT_LG = load_font(34, bold=True)
FONT_XL = load_font(42, bold=True)


def text(draw: ImageDraw.ImageDraw, xy, s: str, font, fill=(0, 0, 0), anchor="la"):
    draw.text(xy, s, font=font, fill=fill, anchor=anchor)


def rounded(draw: ImageDraw.ImageDraw, box, fill, outline=(70, 70, 70), radius=18, width=2):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def dashed_line(draw: ImageDraw.ImageDraw, p1, p2, fill, width=3, dash=12, gap=8):
    x1, y1 = p1
    x2, y2 = p2
    dx = x2 - x1
    dy = y2 - y1
    dist = (dx * dx + dy * dy) ** 0.5
    if dist == 0:
        return
    ux = dx / dist
    uy = dy / dist
    pos = 0
    while pos < dist:
        start = pos
        end = min(pos + dash, dist)
        draw.line(
            (
                x1 + ux * start,
                y1 + uy * start,
                x1 + ux * end,
                y1 + uy * end,
            ),
            fill=fill,
            width=width,
        )
        pos += dash + gap


def arrow(draw: ImageDraw.ImageDraw, p1, p2, fill=(40, 40, 40), width=4, head=12):
    draw.line((p1, p2), fill=fill, width=width)
    x1, y1 = p1
    x2, y2 = p2
    dx = x2 - x1
    dy = y2 - y1
    dist = (dx * dx + dy * dy) ** 0.5
    if dist == 0:
        return
    ux = dx / dist
    uy = dy / dist
    px = -uy
    py = ux
    tip = (x2, y2)
    left = (x2 - ux * head - px * (head * 0.6), y2 - uy * head - py * (head * 0.6))
    right = (x2 - ux * head + px * (head * 0.6), y2 - uy * head + py * (head * 0.6))
    draw.polygon([tip, left, right], fill=fill)


def plus_circle(draw: ImageDraw.ImageDraw, center, radius=14, fill=(255, 255, 255), outline=(70, 70, 70)):
    x, y = center
    draw.ellipse((x - radius, y - radius, x + radius, y + radius), fill=fill, outline=outline, width=2)
    draw.line((x - 6, y, x + 6, y), fill=outline, width=2)
    draw.line((x, y - 6, x, y + 6), fill=outline, width=2)


def panel_title(draw, box, title, tag):
    x1, y1, x2, y2 = box
    text(draw, (x1 + 16, y2 - 16), f"({tag}) {title}", FONT_LG, fill=(30, 30, 30), anchor="ls")


def draw_overall(draw: ImageDraw.ImageDraw, box):
    x1, y1, x2, y2 = box
    rounded(draw, box, fill=(236, 244, 227), outline=(170, 190, 150), radius=24)
    panel_title(draw, box, "Hybrid Mamba-MKDC Seg", "a")

    text(draw, (x1 + 36, y1 + 34), "Input", FONT_LG, fill=(35, 35, 35))
    input_box = (x1 + 28, y1 + 70, x1 + 128, y1 + 170)
    rounded(draw, input_box, fill=(255, 245, 235), outline=(120, 120, 120), radius=14)
    text(draw, ((input_box[0] + input_box[2]) / 2, (input_box[1] + input_box[3]) / 2), "Image", FONT_MD, anchor="mm")
    text(draw, (x1 + 220, y1 + 34), "Encoder channels: C1-C4", FONT_MD)
    text(draw, (x1 + 560, y1 + 34), "Depths: [1, 1, 3, 3]", FONT_MD)

    enc_x = x1 + 120
    dec_x = x1 + 730
    start_y = y1 + 110
    gap_y = 112
    box_w = 120
    box_h = 54

    enc_labels = [
        ("Stem + Stage1", "H x W x C1"),
        ("Down + Stage2", "H/2 x W/2 x C2"),
        ("Down + Stage3", "H/4 x W/4 x C3"),
        ("Down + Stage4", "H/8 x W/8 x C4"),
    ]
    dec_labels = [
        ("Dec4", "Up x2"),
        ("Dec3", "Up x4"),
        ("Dec2", "Up x8"),
        ("Dec1", "Up x16"),
    ]

    enc_centers = []
    dec_centers = []
    for i, (name, shape) in enumerate(enc_labels):
        y = start_y + i * gap_y
        box = (enc_x, y, enc_x + box_w, y + box_h)
        fill = (248, 224, 228) if i < 2 else (232, 222, 247)
        rounded(draw, box, fill=fill, outline=(110, 110, 110), radius=12)
        text(draw, ((box[0] + box[2]) / 2, y + 20), name, FONT_SM, anchor="mm")
        text(draw, ((box[0] + box[2]) / 2, y + 42), shape, FONT_SM, anchor="mm")
        enc_centers.append(((box[0] + box[2]) / 2, (box[1] + box[3]) / 2))
        if i == 0:
            arrow(draw, (input_box[2], (input_box[1] + input_box[3]) / 2), (box[0], (box[1] + box[3]) / 2), fill=(60, 60, 60))
        if i > 0:
            arrow(draw, (enc_centers[i - 1][0], enc_centers[i - 1][1] + box_h / 2), (enc_centers[i][0], enc_centers[i][1] - box_h / 2), fill=(94, 58, 150))

    bottleneck = (enc_x + 10, start_y + 4 * gap_y - 6, enc_x + box_w + 10, start_y + 4 * gap_y + box_h - 6)
    rounded(draw, bottleneck, fill=(198, 227, 255), outline=(110, 110, 110), radius=12)
    text(draw, ((bottleneck[0] + bottleneck[2]) / 2, bottleneck[1] + 20), "Head", FONT_SM, anchor="mm")
    text(draw, ((bottleneck[0] + bottleneck[2]) / 2, bottleneck[1] + 42), "Mamba + MKDC", FONT_SM, anchor="mm")
    arrow(draw, (enc_centers[-1][0], enc_centers[-1][1] + box_h / 2), ((bottleneck[0] + bottleneck[2]) / 2, bottleneck[1]), fill=(94, 58, 150))

    for i, (name, up) in enumerate(dec_labels):
        y = start_y + (3 - i) * gap_y + 10
        gate_box = (dec_x - 150, y + 8, dec_x - 70, y + 46)
        rounded(draw, gate_box, fill=(183, 229, 251), outline=(90, 90, 90), radius=10)
        text(draw, ((gate_box[0] + gate_box[2]) / 2, (gate_box[1] + gate_box[3]) / 2), "Skip", FONT_SM, anchor="mm")
        plus_center = (dec_x - 35, y + 27)
        plus_circle(draw, plus_center)

        box = (dec_x, y, dec_x + box_w, y + box_h)
        rounded(draw, box, fill=(207, 230, 255), outline=(110, 110, 110), radius=12)
        text(draw, ((box[0] + box[2]) / 2, y + 20), name, FONT_SM, anchor="mm")
        text(draw, ((box[0] + box[2]) / 2, y + 42), up, FONT_SM, anchor="mm")
        dec_centers.append(((box[0] + box[2]) / 2, (box[1] + box[3]) / 2))

        skip_y = start_y + (3 - i) * gap_y + box_h / 2
        dashed_line(draw, (enc_x + box_w, skip_y), (gate_box[0], gate_box[1] + 19), fill=(40, 40, 40), width=3)
        arrow(draw, (gate_box[2], gate_box[1] + 19), (plus_center[0] - 14, plus_center[1]), fill=(50, 50, 50), width=3)
        if i == 0:
            arrow(draw, ((bottleneck[0] + bottleneck[2]) / 2, bottleneck[3]), (dec_centers[i][0], dec_centers[i][1] + 28), fill=(40, 120, 160))
        else:
            arrow(draw, (dec_centers[i - 1][0], dec_centers[i - 1][1] - 28), (dec_centers[i][0], dec_centers[i][1] + 28), fill=(40, 120, 160))
        arrow(draw, (plus_center[0] + 14, plus_center[1]), (box[0], box[1] + 27), fill=(50, 50, 50), width=3)

    ds_y = y1 + 488
    aux_box = (dec_x - 30, ds_y, dec_x + 140, ds_y + 48)
    rounded(draw, aux_box, fill=(255, 232, 170), outline=(120, 120, 120), radius=10)
    text(draw, ((aux_box[0] + aux_box[2]) / 2, (aux_box[1] + aux_box[3]) / 2), "Weighted Deep Supervision", FONT_SM, anchor="mm")
    arrow(draw, (dec_centers[-1][0], dec_centers[-1][1] + 28), ((aux_box[0] + aux_box[2]) / 2, aux_box[1]), fill=(200, 140, 20), width=3)
    arrow(draw, (dec_centers[-2][0], dec_centers[-2][1] + 28), (aux_box[0] + 25, aux_box[1]), fill=(200, 140, 20), width=3)

    out_box = (x2 - 120, y1 + 245, x2 - 32, y1 + 305)
    rounded(draw, out_box, fill=(245, 242, 255), outline=(110, 110, 110), radius=12)
    text(draw, ((out_box[0] + out_box[2]) / 2, (out_box[1] + out_box[3]) / 2), "Mask", FONT_MD, anchor="mm")
    arrow(draw, (dec_centers[-1][0] + box_w / 2, dec_centers[-1][1]), (out_box[0], (out_box[1] + out_box[3]) / 2), fill=(60, 60, 60))


def draw_block(draw: ImageDraw.ImageDraw, box):
    rounded(draw, box, fill=(226, 239, 255), outline=(150, 175, 205), radius=22)
    panel_title(draw, box, "Hybrid Mamba Block", "b")
    x1, y1, x2, y2 = box
    text(draw, (x1 + 26, y1 + 34), "Token branch", FONT_MD)
    text(draw, (x1 + 280, y1 + 34), "Local branch", FONT_MD)

    left1 = (x1 + 24, y1 + 78, x1 + 172, y1 + 126)
    left2 = (x1 + 210, y1 + 78, x1 + 358, y1 + 126)
    right1 = (x1 + 24, y1 + 166, x1 + 172, y1 + 214)
    right2 = (x1 + 210, y1 + 166, x1 + 358, y1 + 214)
    merge = (x1 + 410, y1 + 120, x1 + 560, y1 + 170)

    rounded(draw, left1, fill=(248, 235, 255))
    rounded(draw, left2, fill=(248, 235, 255))
    rounded(draw, right1, fill=(220, 245, 215))
    rounded(draw, right2, fill=(220, 245, 215))
    rounded(draw, merge, fill=(255, 238, 201))

    text(draw, ((left1[0] + left1[2]) / 2, (left1[1] + left1[3]) / 2), "LayerNorm", FONT_SM, anchor="mm")
    text(draw, ((left2[0] + left2[2]) / 2, (left2[1] + left2[3]) / 2), "Bi-Mamba3", FONT_SM, anchor="mm")
    text(draw, ((right1[0] + right1[2]) / 2, (right1[1] + right1[3]) / 2), "MKDC", FONT_SM, anchor="mm")
    text(draw, ((right2[0] + right2[2]) / 2, (right2[1] + right2[3]) / 2), "Residual", FONT_SM, anchor="mm")
    text(draw, ((merge[0] + merge[2]) / 2, (merge[1] + merge[3]) / 2), "Adaptive Fusion\n+ MLP", FONT_SM, anchor="mm")

    arrow(draw, (left1[2], (left1[1] + left1[3]) / 2), (left2[0], (left2[1] + left2[3]) / 2))
    arrow(draw, (right1[2], (right1[1] + right1[3]) / 2), (right2[0], (right2[1] + right2[3]) / 2))
    arrow(draw, (left2[2], (left2[1] + left2[3]) / 2), (merge[0], merge[1] + 18))
    arrow(draw, (right2[2], (right2[1] + right2[3]) / 2), (merge[0], merge[3] - 18))


def draw_mkdc(draw: ImageDraw.ImageDraw, box):
    rounded(draw, box, fill=(234, 247, 227), outline=(152, 191, 135), radius=22)
    panel_title(draw, box, "MKDC Local Enhancer", "c")
    x1, y1, x2, y2 = box
    branch_boxes = [
        (x1 + 26, y1 + 70, x1 + 146, y1 + 118, "DWConv 1x1"),
        (x1 + 170, y1 + 70, x1 + 290, y1 + 118, "DWConv 3x3"),
        (x1 + 314, y1 + 70, x1 + 434, y1 + 118, "DWConv 5x5"),
    ]
    for b in branch_boxes:
        rounded(draw, b[:4], fill=(225, 239, 205))
        text(draw, ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2), b[4], FONT_SM, anchor="mm")
    top = ((x1 + x2) / 2, y1 + 42)
    for b in branch_boxes:
        arrow(draw, top, ((b[0] + b[2]) / 2, b[1]))
    sum_center = ((x1 + x2) / 2, y1 + 164)
    plus_circle(draw, sum_center)
    for b in branch_boxes:
        arrow(draw, ((b[0] + b[2]) / 2, b[3]), (sum_center[0], sum_center[1] - 14))
    proj = (x1 + 180, y1 + 192, x1 + 280, y1 + 240)
    rounded(draw, proj, fill=(255, 236, 196))
    text(draw, ((proj[0] + proj[2]) / 2, (proj[1] + proj[3]) / 2), "1x1 Project", FONT_SM, anchor="mm")
    arrow(draw, (sum_center[0], sum_center[1] + 14), ((proj[0] + proj[2]) / 2, proj[1]))


def draw_ds(draw: ImageDraw.ImageDraw, box):
    rounded(draw, box, fill=(255, 242, 226), outline=(210, 181, 145), radius=22)
    panel_title(draw, box, "Weighted Deep Supervision", "d")
    x1, y1, x2, y2 = box
    feats = [
        (x1 + 26, y1 + 82, x1 + 146, y1 + 132, "Dec2"),
        (x1 + 186, y1 + 82, x1 + 306, y1 + 132, "Dec1"),
        (x1 + 346, y1 + 82, x1 + 466, y1 + 132, "Main Head"),
    ]
    heads = [
        (x1 + 26, y1 + 166, x1 + 146, y1 + 214, "Aux Head"),
        (x1 + 186, y1 + 166, x1 + 306, y1 + 214, "Aux Head"),
        (x1 + 346, y1 + 166, x1 + 466, y1 + 214, "Seg Head"),
    ]
    colors = [(230, 238, 255), (230, 238, 255), (210, 244, 210)]
    for b, c in zip(feats, colors):
        rounded(draw, b[:4], fill=c)
        text(draw, ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2), b[4], FONT_SM, anchor="mm")
    for b, c in zip(heads, colors):
        rounded(draw, b[:4], fill=c)
        text(draw, ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2), b[4], FONT_SM, anchor="mm")
    for b1, b2 in zip(feats, heads):
        arrow(draw, ((b1[0] + b1[2]) / 2, b1[3]), ((b2[0] + b2[2]) / 2, b2[1]))
    loss = (x2 - 132, y1 + 120, x2 - 26, y1 + 176)
    rounded(draw, loss, fill=(255, 221, 165))
    text(draw, ((loss[0] + loss[2]) / 2, (loss[1] + loss[3]) / 2), "Loss\nmain + 0.3 aux", FONT_SM, anchor="mm")
    for b in heads:
        arrow(draw, (b[2], (b[1] + b[3]) / 2), (loss[0], (loss[1] + loss[3]) / 2))


def main():
    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    image = Image.new("RGB", (1800, 1100), (247, 247, 244))
    draw = ImageDraw.Draw(image)

    text(draw, (900, 36), "Our Hybrid Mamba-MKDC Segmentation Architecture", FONT_XL, anchor="mm", fill=(25, 25, 25))

    overall = (28, 82, 1260, 760)
    block = (40, 790, 660, 1060)
    mkdc = (690, 790, 1160, 1060)
    ds = (1190, 790, 1768, 1060)

    draw_overall(draw, overall)
    draw_block(draw, block)
    draw_mkdc(draw, mkdc)
    draw_ds(draw, ds)

    note_box = (1292, 102, 1768, 744)
    rounded(draw, note_box, fill=(244, 248, 255), outline=(178, 192, 218), radius=24)
    panel_title(draw, note_box, "Key Design Notes", "e")
    notes = [
        "1. Encoder depths: [1, 1, 3, 3]",
        "2. Each stage couples global Mamba3",
        "   with multi-kernel local enhancement.",
        "3. Decoder uses skip fusion and",
        "   weighted deep supervision.",
        "4. Final training recipe:",
        "   BCE + IoU, aux weight = 0.3",
        "5. Designed for medical segmentation",
        "   where boundary and context matter.",
    ]
    y = 160
    for line in notes:
        text(draw, (1322, y), line, FONT_MD, fill=(40, 40, 40))
        y += 54

    image.save(OUT_PATH, quality=95)
    print(f"saved to {OUT_PATH}")


if __name__ == "__main__":
    main()
