__version__ = '2.3.1'

try:
    from mamba_ssm.ops.selective_scan_interface import selective_scan_fn, mamba_inner_fn
except ImportError:
    selective_scan_fn = None
    mamba_inner_fn = None

try:
    from mamba_ssm.modules.mamba_simple import Mamba
except ImportError:
    Mamba = None

try:
    from mamba_ssm.modules.mamba2 import Mamba2
except ImportError:
    Mamba2 = None

try:
    from mamba_ssm.modules.mamba3 import Mamba3
except ImportError:
    Mamba3 = None

try:
    from mamba_ssm.models.mixer_seq_simple import MambaLMHeadModel
except ImportError:
    MambaLMHeadModel = None

try:
    from mamba_ssm.models.vision_mamba3_seg import VisionMamba3Seg
except ImportError:
    VisionMamba3Seg = None

__all__ = [
    '__version__',
    'selective_scan_fn',
    'mamba_inner_fn',
    'Mamba',
    'Mamba2',
    'Mamba3',
    'MambaLMHeadModel',
    'VisionMamba3Seg',
]
