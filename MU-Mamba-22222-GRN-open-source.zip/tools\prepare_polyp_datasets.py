from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path
from random import Random
from typing import Iterable


SUBDATASET_DIRS = {
    'ClinicDB': ('Original', 'Ground Truth'),
    'CVC-300': ('images', 'masks'),
    'CVC-ColonDB': ('images', 'masks'),
    'ETIS': ('images', 'masks'),
    'kvasir-seg': ('images', 'masks'),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description='Create repeated 8:1:1 train/val/test splits for the five polyp subdatasets.'
    )
    parser.add_argument('--root', type=Path, default=Path('data/polyp'))
    parser.add_argument('--out-root', type=Path, default=Path('data/polyp_splits'))
    parser.add_argument('--seeds', type=str, default='42,52,62,72,82')
    parser.add_argument('--overwrite', action='store_true')
    return parser.parse_args()


def parse_seed_list(raw: str) -> list[int]:
    seeds = [int(part.strip()) for part in raw.split(',') if part.strip()]
    if not seeds:
        raise ValueError('expected at least one seed')
    return seeds


def collect_pairs(images_dir: Path, masks_dir: Path) -> list[tuple[Path, Path]]:
    image_map = {path.stem: path for path in images_dir.iterdir() if path.is_file()}
    mask_map = {path.stem: path for path in masks_dir.iterdir() if path.is_file()}
    shared = sorted(set(image_map) & set(mask_map))
    if not shared:
        raise RuntimeError(f'no matched image/mask pairs found in {images_dir} and {masks_dir}')
    missing_images = sorted(set(mask_map) - set(image_map))
    missing_masks = sorted(set(image_map) - set(mask_map))
    if missing_images or missing_masks:
        raise RuntimeError(
            f'unmatched files between {images_dir} and {masks_dir}; '
            f'missing_images={len(missing_images)} missing_masks={len(missing_masks)}'
        )
    return [(image_map[key], mask_map[key]) for key in shared]


def split_counts(num_items: int) -> tuple[int, int, int]:
    train = int(num_items * 0.8)
    val = int(num_items * 0.1)
    test = num_items - train - val
    return train, val, test


def ensure_split_dirs(base_dir: Path) -> None:
    for split in ('train', 'val', 'test'):
        (base_dir / split / 'images').mkdir(parents=True, exist_ok=True)
        (base_dir / split / 'masks').mkdir(parents=True, exist_ok=True)


def copy_pairs(pairs: Iterable[tuple[Path, Path]], dest_root: Path, split_name: str) -> int:
    count = 0
    for image_path, mask_path in pairs:
        shutil.copy2(image_path, dest_root / split_name / 'images' / image_path.name)
        shutil.copy2(mask_path, dest_root / split_name / 'masks' / mask_path.name)
        count += 1
    return count


def main() -> None:
    args = parse_args()
    seeds = parse_seed_list(args.seeds)
    args.out_root.mkdir(parents=True, exist_ok=True)

    summary: dict[str, dict[str, dict[str, int] | int | str]] = {}

    for dataset_name, (image_dir_name, mask_dir_name) in SUBDATASET_DIRS.items():
        dataset_root = args.root / dataset_name
        images_dir = dataset_root / image_dir_name
        masks_dir = dataset_root / mask_dir_name
        if not images_dir.exists() or not masks_dir.exists():
            raise FileNotFoundError(
                f'expected {dataset_name} to contain {image_dir_name} and {mask_dir_name}'
            )
        pairs = collect_pairs(images_dir, masks_dir)
        total = len(pairs)
        train_count, val_count, test_count = split_counts(total)

        dataset_summary: dict[str, dict[str, int] | int | str] = {
            'source_images_dir': str(images_dir),
            'source_masks_dir': str(masks_dir),
            'num_pairs': total,
        }

        for seed in seeds:
            out_dir = args.out_root / f'{dataset_name}_split_8_1_1_seed{seed}'
            if out_dir.exists():
                if not args.overwrite:
                    raise FileExistsError(
                        f'{out_dir} already exists; pass --overwrite to replace existing splits'
                    )
                shutil.rmtree(out_dir)

            shuffled = pairs[:]
            Random(seed).shuffle(shuffled)
            train_pairs = shuffled[:train_count]
            val_pairs = shuffled[train_count:train_count + val_count]
            test_pairs = shuffled[train_count + val_count:]

            ensure_split_dirs(out_dir)
            train_written = copy_pairs(train_pairs, out_dir, 'train')
            val_written = copy_pairs(val_pairs, out_dir, 'val')
            test_written = copy_pairs(test_pairs, out_dir, 'test')

            split_summary = {
                'train': train_written,
                'val': val_written,
                'test': test_written,
            }
            with (out_dir / 'split_summary.json').open('w', encoding='utf-8') as handle:
                json.dump(
                    {
                        'dataset': dataset_name,
                        'seed': seed,
                        'num_pairs': total,
                        'train': train_written,
                        'val': val_written,
                        'test': test_written,
                        'source_images_dir': str(images_dir),
                        'source_masks_dir': str(masks_dir),
                    },
                    handle,
                    indent=2,
                )
            dataset_summary[f'seed{seed}'] = split_summary

        summary[dataset_name] = dataset_summary

    with (args.out_root / 'polyp_split_summary.json').open('w', encoding='utf-8') as handle:
        json.dump(summary, handle, indent=2)

    print(f'Prepared repeated 8:1:1 splits under {args.out_root}')
    for dataset_name, dataset_summary in summary.items():
        print(f'{dataset_name}: total={dataset_summary["num_pairs"]}')
        for seed in seeds:
            counts = dataset_summary[f'seed{seed}']
            print(
                f'  seed{seed}: train={counts["train"]} '
                f'val={counts["val"]} test={counts["test"]}'
            )


if __name__ == '__main__':
    main()
