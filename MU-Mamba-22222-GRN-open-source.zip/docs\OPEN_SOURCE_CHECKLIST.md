# Open-Source Release Checklist

Use this checklist before pushing the clean MU-Mamba release to GitHub.

## Must Not Commit

- Raw datasets under `data/`
- Predictions and experiment folders under `outputs/`
- Local pretrained weights or checkpoints: `*.pth`, `*.pt`, `*.ckpt`, `*.npz`
- Python environments: `.venv/`, `venv/`, `env/`
- Local cache folders: `.triton_cache/`, `.tmp/`, `__pycache__/`
- Draft papers or private notes

## Expected Clean Release

This folder is intended to contain only the final MU-Mamba 22222+GRN implementation:

- `mamba_ssm/`
- `tools/train_mamba3_seg.py`
- `tools/eval_mamba3_seg.py`
- dataset preparation utilities
- visualization utility
- `configs/`
- `docs/`

It should not contain non-release model branches, old automatic search scripts, datasets, outputs, or pretrained weights.

## Before First Push

```bash
git init
git add README.md LICENSE requirements.txt requirements-medseg.txt .gitignore
git add mamba_ssm tools configs docs csrc rocm_patch tests
git status --short
git commit -m "Initial release of MU-Mamba"
```
