from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image, ImageDraw, ImageFont

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from mamba_ssm.data.fast_binary_segmentation import FastBinarySegmentationDataset
from mamba_ssm.data.medical_segmentation import MedicalSegmentationDataset, collect_paired_cases, infer_input_mode
from mamba_ssm.models.vision_mamba3_seg import GuidedAxialGRNSkipBridge
from tools.eval_mamba3_seg import _checkpoint_value, _optional_tuple
from tools.train_mamba3_seg import build_model, load_checkpoint, split_model_outputs


def parse_optional_float(value: str | None):
    if value is None:
        return None
    lowered = str(value).strip().lower()
    if lowered in {"none", "null"}:
        return None
    return float(value)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Visualize feature changes around Ours DGASF/GRN skip bridge.")
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--split", type=str, default="test")
    parser.add_argument("--out-file", type=Path, default=Path("outputs/feature_change/ours_feature_change.png"))
    parser.add_argument("--sample-index", type=int, default=None, help="Use a fixed sample index instead of auto-picking.")
    parser.add_argument("--max-samples", type=int, default=80)
    parser.add_argument("--bridge-index", type=int, default=-1, help="-1 means the last/highest-resolution bridge.")
    parser.add_argument("--image-size", type=int, default=None)
    parser.add_argument("--window-min", type=parse_optional_float, default=None)
    parser.add_argument("--window-max", type=parse_optional_float, default=None)
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--amp", action="store_true")
    parser.add_argument("--amp-dtype", choices=["fp16", "bf16"], default="bf16")
    return parser.parse_args()


def build_model_args(checkpoint_args: dict[str, Any]) -> argparse.Namespace:
    return argparse.Namespace(
        in_channels=checkpoint_args.get("in_channels", 1),
        num_classes=checkpoint_args.get("num_classes", 1),
        base_dim=checkpoint_args.get("base_dim", 32),
        depths=checkpoint_args.get("depths", "2,2,2,2,2"),
        d_state=checkpoint_args.get("d_state", 64),
        headdim=checkpoint_args.get("headdim", 32),
        expand=checkpoint_args.get("expand", 2),
        chunk_size=checkpoint_args.get("chunk_size", 64),
        mlp_ratio=checkpoint_args.get("mlp_ratio", 2.0),
        dropout=checkpoint_args.get("dropout", 0.0),
        drop_path=checkpoint_args.get("drop_path", 0.1),
        disable_bidirectional=checkpoint_args.get("disable_bidirectional", False),
        local_mode=checkpoint_args.get("local_mode", "dmkdc"),
        stage_local_modes=_optional_tuple(checkpoint_args.get("stage_local_modes")),
        mkdc_kernel_sizes=tuple(checkpoint_args.get("mkdc_kernel_sizes", (1, 3, 5))),
        decoder_skip_bridge=checkpoint_args.get("decoder_skip_bridge", "guided_axial_seq_grn"),
        deep_supervision=checkpoint_args.get("deep_supervision", False),
    )


def build_dataset(args: argparse.Namespace, checkpoint: dict[str, Any], checkpoint_args: dict[str, Any]):
    image_size = int(_checkpoint_value(args.image_size, checkpoint_args, "image_size", 256))
    slice_axis = int(_checkpoint_value(None, checkpoint_args, "slice_axis", -1))
    window_min = _checkpoint_value(args.window_min, checkpoint_args, "window_min", None)
    window_max = _checkpoint_value(args.window_max, checkpoint_args, "window_max", None)

    fast_array = (args.data_root / "arrays" / f"{args.split}_images.npy").exists()
    if fast_array:
        return FastBinarySegmentationDataset(args.data_root, args.split, image_size=image_size, train=False, augment=False)

    images_dir = args.data_root / args.split / "images"
    masks_dir = args.data_root / args.split / "masks"
    cases = collect_paired_cases(images_dir, masks_dir)
    input_mode = _checkpoint_value(None, {"input_mode": checkpoint.get("input_mode")}, "input_mode", None)
    if input_mode is None:
        input_mode = _checkpoint_value(None, checkpoint_args, "input_mode", "auto")
    if input_mode == "auto":
        input_mode = infer_input_mode(cases)
    return MedicalSegmentationDataset(
        cases,
        input_mode=input_mode,
        image_size=image_size,
        train=False,
        slice_axis=slice_axis,
        keep_empty_slices=True,
        slice_neighbors=0,
        window_min=window_min,
        window_max=window_max,
    )


def dice_from_logits(logits: torch.Tensor, mask: torch.Tensor, eps: float = 1e-6) -> float:
    pred = (torch.sigmoid(logits) > 0.5).float()
    target = (mask > 0.5).float()
    inter = (pred * target).sum()
    denom = pred.sum() + target.sum()
    return float(((2.0 * inter + eps) / (denom + eps)).detach().cpu())


def normalize_map(array: np.ndarray) -> np.ndarray:
    array = np.asarray(array, dtype=np.float32)
    finite = np.isfinite(array)
    if not finite.any():
        return np.zeros_like(array, dtype=np.float32)
    lo, hi = np.percentile(array[finite], [1, 99])
    if hi <= lo:
        lo, hi = float(array[finite].min()), float(array[finite].max())
    if hi <= lo:
        return np.zeros_like(array, dtype=np.float32)
    return np.clip((array - lo) / (hi - lo), 0.0, 1.0)


def feature_energy(feature: torch.Tensor, size: tuple[int, int]) -> np.ndarray:
    energy = feature.detach().float().abs().mean(dim=1, keepdim=True)
    energy = F.interpolate(energy, size=size, mode="bilinear", align_corners=False)
    return normalize_map(energy[0, 0].cpu().numpy())


def image_for_plot(image: torch.Tensor) -> np.ndarray:
    image_np = image.detach().cpu().float().numpy()
    if image_np.shape[0] == 1:
        return normalize_map(image_np[0])
    rgb = np.transpose(image_np[:3], (1, 2, 0))
    return normalize_map(rgb)


def _interp_colormap(values: np.ndarray, colors: list[tuple[float, tuple[int, int, int]]]) -> np.ndarray:
    values = np.clip(values.astype(np.float32), 0.0, 1.0)
    out = np.zeros((*values.shape, 3), dtype=np.float32)
    stops = [stop for stop, _ in colors]
    rgb = np.array([color for _, color in colors], dtype=np.float32)
    for idx in range(len(stops) - 1):
        lo, hi = stops[idx], stops[idx + 1]
        mask = (values >= lo) & (values <= hi)
        t = (values[mask] - lo) / max(hi - lo, 1e-6)
        out[mask] = rgb[idx] * (1.0 - t[:, None]) + rgb[idx + 1] * t[:, None]
    out[values <= stops[0]] = rgb[0]
    out[values >= stops[-1]] = rgb[-1]
    return out.astype(np.uint8)


def to_rgb(array: np.ndarray, cmap: str | None = None) -> np.ndarray:
    array = normalize_map(array)
    if array.ndim == 3:
        return (np.clip(array, 0.0, 1.0) * 255.0).astype(np.uint8)
    if cmap in {None, "gray"}:
        gray = (array * 255.0).astype(np.uint8)
        return np.repeat(gray[..., None], 3, axis=2)
    if cmap == "magma":
        return _interp_colormap(
            array,
            [
                (0.00, (0, 0, 4)),
                (0.25, (80, 18, 123)),
                (0.50, (182, 54, 121)),
                (0.75, (251, 136, 97)),
                (1.00, (252, 253, 191)),
            ],
        )
    if cmap == "viridis":
        return _interp_colormap(
            array,
            [
                (0.00, (68, 1, 84)),
                (0.33, (49, 104, 142)),
                (0.66, (53, 183, 121)),
                (1.00, (253, 231, 37)),
            ],
        )
    if cmap == "coolwarm":
        return _interp_colormap(
            array,
            [
                (0.00, (59, 76, 192)),
                (0.50, (221, 221, 221)),
                (1.00, (180, 4, 38)),
            ],
        )
    raise ValueError(f"unknown cmap {cmap!r}")


def mask_boundary(mask: np.ndarray) -> np.ndarray:
    binary = mask > 0.5
    neighbors = (
        np.roll(binary, 1, axis=0)
        & np.roll(binary, -1, axis=0)
        & np.roll(binary, 1, axis=1)
        & np.roll(binary, -1, axis=1)
    )
    boundary = binary & ~neighbors
    boundary[[0, -1], :] = False
    boundary[:, [0, -1]] = False
    return boundary


def blend_overlay(base: np.ndarray, heat: np.ndarray, mask: np.ndarray, pred: np.ndarray) -> np.ndarray:
    base_rgb = to_rgb(base, None)
    heat_rgb = to_rgb(heat, "magma")
    overlay = (base_rgb.astype(np.float32) * 0.56 + heat_rgb.astype(np.float32) * 0.44).astype(np.uint8)
    gt_edge = mask_boundary(mask)
    pred_edge = mask_boundary(pred)
    overlay[gt_edge] = np.array([80, 255, 80], dtype=np.uint8)
    overlay[pred_edge] = np.array([0, 230, 255], dtype=np.uint8)
    return overlay


def make_panel(image: np.ndarray, title: str, size: int = 256) -> Image.Image:
    panel = Image.new("RGB", (size, size + 28), "white")
    img = Image.fromarray(image).resize((size, size), Image.Resampling.BILINEAR)
    panel.paste(img, (0, 28))
    draw = ImageDraw.Draw(panel)
    try:
        font = ImageFont.truetype("arial.ttf", 16)
    except OSError:
        font = ImageFont.load_default()
    draw.text((8, 6), title, fill=(20, 20, 20), font=font)
    return panel


def save_grid(panels: list[tuple[str, np.ndarray]], out_file: Path, title: str) -> None:
    panel_size = 256
    cols = 4
    rows = 2
    title_h = 42
    gap = 12
    canvas_w = cols * panel_size + (cols + 1) * gap
    canvas_h = title_h + rows * (panel_size + 28) + (rows + 1) * gap
    canvas = Image.new("RGB", (canvas_w, canvas_h), "white")
    draw = ImageDraw.Draw(canvas)
    try:
        title_font = ImageFont.truetype("arial.ttf", 20)
    except OSError:
        title_font = ImageFont.load_default()
    draw.text((gap, 10), title, fill=(10, 10, 10), font=title_font)
    for idx, (panel_title, panel_image) in enumerate(panels):
        row = idx // cols
        col = idx % cols
        x = gap + col * (panel_size + gap)
        y = title_h + gap + row * (panel_size + 28 + gap)
        canvas.paste(make_panel(panel_image, panel_title, panel_size), (x, y))
    out_file.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(out_file)


def main() -> None:
    args = parse_args()
    checkpoint = load_checkpoint(args.checkpoint, map_location="cpu")
    checkpoint_args = checkpoint.get("args", {})
    if int(checkpoint_args.get("num_classes", 1)) != 1:
        raise ValueError("This visualization script currently supports binary checkpoints only.")

    requested_device = torch.device(args.device)
    device = torch.device("cpu") if requested_device.type == "cuda" and not torch.cuda.is_available() else requested_device
    amp_dtype = torch.float16 if args.amp_dtype == "fp16" else torch.bfloat16
    amp_enabled = bool(args.amp and device.type == "cuda")

    model = build_model(build_model_args(checkpoint_args)).to(device)
    model.load_state_dict(checkpoint["model"])
    model.eval()

    bridges = [module for module in model.modules() if isinstance(module, GuidedAxialGRNSkipBridge)]
    if not bridges:
        raise RuntimeError("No GuidedAxialGRNSkipBridge found. Use a checkpoint with --decoder-skip-bridge guided_axial_seq_grn.")
    bridge = bridges[args.bridge_index]
    captured: dict[str, torch.Tensor] = {}

    def bridge_hook(_module, inputs, output):
        captured["skip_before"] = inputs[0].detach()
        captured["after_grn"] = output.detach()
        gate = getattr(_module, "last_gates", None)
        if gate is not None:
            captured["gates"] = gate.detach()

    def inner_bridge_hook(_module, _inputs, output):
        captured["after_dgasf"] = output.detach()

    handle = bridge.register_forward_hook(bridge_hook)
    inner_handle = bridge.bridge.register_forward_hook(inner_bridge_hook)

    dataset = build_dataset(args, checkpoint, checkpoint_args)
    candidate_indices = [args.sample_index] if args.sample_index is not None else range(min(len(dataset), int(args.max_samples)))

    best = None
    with torch.no_grad():
        for idx in candidate_indices:
            sample = dataset[int(idx)]
            image = sample["image"].unsqueeze(0).to(device)
            mask = sample["mask"].unsqueeze(0).to(device)
            captured.clear()
            with torch.autocast(device_type=device.type, enabled=amp_enabled, dtype=amp_dtype):
                outputs = model(image)
            logits, _ = split_model_outputs(outputs)
            dice = dice_from_logits(logits.float(), mask)
            area = float(mask.mean().detach().cpu())
            if area <= 0.005 or area >= 0.60 or "skip_before" not in captured:
                continue
            score = dice - 0.15 * abs(area - 0.12)
            if best is None or score > best["score"]:
                best = {
                    "score": score,
                    "index": int(idx),
                    "id": sample.get("id", str(idx)),
                    "image": sample["image"].detach().cpu(),
                    "mask": sample["mask"].detach().cpu(),
                    "logits": logits.detach().cpu(),
                    "dice": dice,
                    "area": area,
                    "skip_before": captured["skip_before"].detach().cpu(),
                    "after_dgasf": captured.get("after_dgasf", captured["after_grn"]).detach().cpu(),
                    "after_grn": captured["after_grn"].detach().cpu(),
                    "gates": captured.get("gates", torch.empty(0)).detach().cpu(),
                }
    handle.remove()
    inner_handle.remove()
    if best is None:
        raise RuntimeError("Could not find a suitable sample. Try --sample-index or increase --max-samples.")

    image = best["image"]
    mask = best["mask"][0].numpy()
    pred = (torch.sigmoid(best["logits"])[0, 0] > 0.5).float().numpy()
    size = tuple(image.shape[-2:])
    before = feature_energy(best["skip_before"], size)
    after_dgasf = feature_energy(best["after_dgasf"], size)
    after = feature_energy(best["after_grn"], size)
    delta = normalize_map(after - before)
    gates = best["gates"]
    if gates.numel() > 0:
        row_gate = F.interpolate(gates[:, 0:1].float(), size=size, mode="bilinear", align_corners=False)[0, 0].numpy()
        col_gate = F.interpolate(gates[:, 1:2].float(), size=size, mode="bilinear", align_corners=False)[0, 0].numpy()
        gate_map = normalize_map((row_gate + col_gate) * 0.5)
    else:
        gate_map = np.zeros(size, dtype=np.float32)

    base = image_for_plot(image)
    panels = [
        ("Input", to_rgb(base, None)),
        ("GT Mask", to_rgb(mask, "gray")),
        ("Prediction", to_rgb(pred, "gray")),
        ("Baseline Skip", to_rgb(before, "magma")),
        ("+DGASF", to_rgb(after_dgasf, "magma")),
        ("+DGASF+GRN", to_rgb(after, "magma")),
        ("Feature Change", to_rgb(delta, "coolwarm")),
        ("Overlay", blend_overlay(base, after, mask, pred)),
    ]
    title = f"Ours DGASF+GRN Feature Change | sample={best['id']} | Dice={best['dice']:.4f}"
    save_grid(panels, args.out_file, title)
    print(f"Saved feature change figure to {args.out_file}")
    print(f"Selected sample index={best['index']} id={best['id']} dice={best['dice']:.4f} mask_area={best['area']:.4f}")


if __name__ == "__main__":
    main()
