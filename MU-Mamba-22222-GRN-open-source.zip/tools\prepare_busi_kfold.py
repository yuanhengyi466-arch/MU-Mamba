from __future__ import annotations

import argparse
import json
import random
import shutil
from pathlib import Path
from typing import Dict, List

import numpy as np
from PIL import Image


IMAGE_SUFFIXES = {'.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff'}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description='Prepare Dataset_BUSI_with_GT into stratified k-fold train/val/test folders.'
    )
    parser.add_argument('--input-dir', type=Path, required=True, help='Path to Dataset_BUSI_with_GT root.')
    parser.add_argument('--output-dir', type=Path, required=True, help='Output dataset root.')
    parser.add_argument('--num-folds', type=int, default=5, help='Number of folds for cross-validation.')
    parser.add_argument(
        '--val-fold-offset',
        type=int,
        default=1,
        help='Use fold (test_fold + offset) mod K as validation fold.',
    )
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--overwrite', action='store_true', help='Delete output-dir if it already exists.')
    return parser.parse_args()


def ensure_clean_dir(path: Path, overwrite: bool) -> None:
    if path.exists():
        if not overwrite:
            raise FileExistsError(f'output directory already exists: {path}')
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def sample_id(class_name: str, stem: str) -> str:
    return f'{class_name}__{stem}'


def collect_samples(input_dir: Path) -> List[Dict[str, object]]:
    if not input_dir.exists():
        raise FileNotFoundError(f'input directory does not exist: {input_dir}')

    samples: List[Dict[str, object]] = []
    for class_dir in sorted(path for path in input_dir.iterdir() if path.is_dir()):
        for image_path in sorted(class_dir.iterdir()):
            if not image_path.is_file() or image_path.suffix.lower() not in IMAGE_SUFFIXES:
                continue
            if '_mask' in image_path.stem.lower():
                continue
            mask_paths = sorted(class_dir.glob(f'{image_path.stem}_mask*.png'))
            if not mask_paths:
                raise FileNotFoundError(f'no masks found for image: {image_path}')
            samples.append(
                {
                    'id': sample_id(class_dir.name, image_path.stem),
                    'class_name': class_dir.name,
                    'image_path': image_path,
                    'mask_paths': mask_paths,
                }
            )

    if not samples:
        raise ValueError(f'no BUSI image/mask pairs found under {input_dir}')
    return samples


def stratified_kfold_assignments(
    samples: List[Dict[str, object]],
    num_folds: int,
    seed: int,
) -> List[List[Dict[str, object]]]:
    if num_folds < 3:
        raise ValueError('num_folds must be at least 3 when creating train/val/test splits')

    grouped: Dict[str, List[Dict[str, object]]] = {}
    for sample in samples:
        grouped.setdefault(str(sample['class_name']), []).append(sample)

    rng = random.Random(seed)
    folds: List[List[Dict[str, object]]] = [[] for _ in range(num_folds)]
    for class_name, class_samples in sorted(grouped.items()):
        class_samples = list(class_samples)
        rng.shuffle(class_samples)
        for index, sample in enumerate(class_samples):
            folds[index % num_folds].append(sample)

    for fold in folds:
        fold.sort(key=lambda item: str(item['id']))
    return folds


def merge_masks(mask_paths: List[Path]) -> Image.Image:
    merged = None
    for mask_path in mask_paths:
        mask = np.asarray(Image.open(mask_path).convert('L'), dtype=np.uint8) > 0
        merged = mask if merged is None else np.logical_or(merged, mask)
    return Image.fromarray((merged.astype(np.uint8) * 255), mode='L')


def save_split(output_dir: Path, split_name: str, samples: List[Dict[str, object]]) -> Dict[str, object]:
    images_dir = output_dir / split_name / 'images'
    masks_dir = output_dir / split_name / 'masks'
    images_dir.mkdir(parents=True, exist_ok=True)
    masks_dir.mkdir(parents=True, exist_ok=True)

    class_counts: Dict[str, int] = {}
    ids: List[str] = []
    for sample in samples:
        image_path = Path(str(sample['image_path']))
        mask_paths = list(sample['mask_paths'])
        class_name = str(sample['class_name'])
        sid = str(sample['id'])
        ids.append(sid)
        class_counts[class_name] = class_counts.get(class_name, 0) + 1

        image = Image.open(image_path).convert('RGB')
        mask = merge_masks(mask_paths)
        image.save(images_dir / f'{sid}.png')
        mask.save(masks_dir / f'{sid}.png')

    return {'count': len(samples), 'class_counts': class_counts, 'ids': ids}


def main() -> None:
    args = parse_args()
    ensure_clean_dir(args.output_dir, overwrite=args.overwrite)

    samples = collect_samples(args.input_dir)
    folds = stratified_kfold_assignments(samples=samples, num_folds=args.num_folds, seed=args.seed)

    summary = {
        'input_dir': str(args.input_dir),
        'output_dir': str(args.output_dir),
        'seed': int(args.seed),
        'num_folds': int(args.num_folds),
        'val_fold_offset': int(args.val_fold_offset),
        'total_samples': len(samples),
        'folds': {},
    }

    for fold_index in range(args.num_folds):
        test_fold = fold_index
        val_fold = (fold_index + args.val_fold_offset) % args.num_folds
        train_samples: List[Dict[str, object]] = []
        val_samples = list(folds[val_fold])
        test_samples = list(folds[test_fold])
        for index, fold_samples in enumerate(folds):
            if index in {test_fold, val_fold}:
                continue
            train_samples.extend(fold_samples)
        train_samples.sort(key=lambda item: str(item['id']))

        fold_dir = args.output_dir / f'fold{fold_index + 1}'
        fold_dir.mkdir(parents=True, exist_ok=True)
        summary['folds'][f'fold{fold_index + 1}'] = {
            'train': save_split(fold_dir, 'train', train_samples),
            'val': save_split(fold_dir, 'val', val_samples),
            'test': save_split(fold_dir, 'test', test_samples),
            'test_fold_index': test_fold,
            'val_fold_index': val_fold,
        }

    summary_path = args.output_dir / 'kfold_summary.json'
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
