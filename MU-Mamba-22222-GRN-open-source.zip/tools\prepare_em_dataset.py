from __future__ import annotations

import argparse
import json
import random
import shutil
from pathlib import Path
from typing import List, Tuple


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description='Prepare the EM dataset into train/val/test image-mask folders.')
    parser.add_argument('--data-dir', type=Path, default=Path('data/EM'))
    parser.add_argument('--output-dir', type=Path, default=Path('data/EM_8_1_1'))
    parser.add_argument('--train-ratio', type=float, default=0.8)
    parser.add_argument('--val-ratio', type=float, default=0.1)
    parser.add_argument('--test-ratio', type=float, default=0.1)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--overwrite', action='store_true')
    return parser.parse_args()


def collect_pairs(data_dir: Path) -> List[Tuple[Path, Path]]:
    images_dir = data_dir / 'imgs'
    masks_dir = data_dir / 'labels'
    if not images_dir.exists() or not masks_dir.exists():
        raise FileNotFoundError(f'expected imgs/ and labels/ under {data_dir}')

    pairs: List[Tuple[Path, Path]] = []
    for image_path in sorted(images_dir.glob('*.png')):
        mask_path = masks_dir / image_path.name
        if not mask_path.exists():
            raise FileNotFoundError(f'missing mask for {image_path.name}: {mask_path}')
        pairs.append((image_path, mask_path))
    if not pairs:
        raise RuntimeError(f'no .png image/mask pairs found under {data_dir}')
    return pairs


def ensure_clean_dir(output_dir: Path, overwrite: bool) -> None:
    if output_dir.exists():
        if not overwrite:
            raise FileExistsError(f'output directory already exists: {output_dir}')
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)


def copy_split(samples: List[Tuple[Path, Path]], output_dir: Path, split_name: str) -> List[str]:
    image_dst = output_dir / split_name / 'images'
    mask_dst = output_dir / split_name / 'masks'
    image_dst.mkdir(parents=True, exist_ok=True)
    mask_dst.mkdir(parents=True, exist_ok=True)

    ids: List[str] = []
    for image_path, mask_path in samples:
        shutil.copy2(image_path, image_dst / image_path.name)
        shutil.copy2(mask_path, mask_dst / mask_path.name)
        ids.append(image_path.stem)
    return ids


def main() -> None:
    args = parse_args()
    total_ratio = args.train_ratio + args.val_ratio + args.test_ratio
    if abs(total_ratio - 1.0) > 1e-6:
        raise ValueError(f'train/val/test ratios must sum to 1.0, got {total_ratio}')

    pairs = collect_pairs(args.data_dir)
    random.Random(args.seed).shuffle(pairs)
    count = len(pairs)
    train_count = int(count * args.train_ratio)
    val_count = int(count * args.val_ratio)
    test_count = count - train_count - val_count
    if min(train_count, val_count, test_count) <= 0:
        raise ValueError(
            f'invalid split sizes for {count} samples: '
            f'train={train_count}, val={val_count}, test={test_count}'
        )

    train_pairs = pairs[:train_count]
    val_pairs = pairs[train_count:train_count + val_count]
    test_pairs = pairs[train_count + val_count:]

    ensure_clean_dir(args.output_dir, overwrite=args.overwrite)
    train_ids = copy_split(train_pairs, args.output_dir, 'train')
    val_ids = copy_split(val_pairs, args.output_dir, 'val')
    test_ids = copy_split(test_pairs, args.output_dir, 'test')

    summary = {
        'data_dir': str(args.data_dir),
        'output_dir': str(args.output_dir),
        'seed': args.seed,
        'counts': {
            'train': len(train_ids),
            'val': len(val_ids),
            'test': len(test_ids),
            'total': count,
        },
        'splits': {
            'train': train_ids,
            'val': val_ids,
            'test': test_ids,
        },
    }
    with (args.output_dir / 'split_summary.json').open('w', encoding='utf-8') as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)

    print(
        f'Prepared EM dataset at {args.output_dir} '
        f'with train={len(train_ids)}, val={len(val_ids)}, test={len(test_ids)}'
    )


if __name__ == '__main__':
    main()
