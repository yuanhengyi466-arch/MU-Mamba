from __future__ import annotations

import argparse
import json
import random
import shutil
from pathlib import Path
from typing import Dict, List


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description='Prepare ISIC2018 Task 1 dataset into train/val/test images+masks directories.'
    )
    parser.add_argument('--input-root', type=Path, required=True, help='Path to ISIC2018 root directory.')
    parser.add_argument('--output-dir', type=Path, required=True, help='Output dataset root.')
    parser.add_argument('--train-ratio', type=float, default=0.8)
    parser.add_argument('--val-ratio', type=float, default=0.1)
    parser.add_argument('--test-ratio', type=float, default=0.1)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--overwrite', action='store_true', help='Delete output-dir if it already exists.')
    return parser.parse_args()


def validate_ratios(train_ratio: float, val_ratio: float, test_ratio: float) -> None:
    total = train_ratio + val_ratio + test_ratio
    if abs(total - 1.0) > 1e-6:
        raise ValueError(f'ratios must sum to 1.0, got {total:.6f}')
    if min(train_ratio, val_ratio, test_ratio) <= 0:
        raise ValueError('all split ratios must be positive')


def ensure_clean_dir(path: Path, overwrite: bool) -> None:
    if path.exists():
        if not overwrite:
            raise FileExistsError(f'output directory already exists: {path}')
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def collect_samples(input_root: Path) -> List[Dict[str, Path]]:
    image_dir = input_root / 'ISIC2018_Task1-2_Training_Input'
    mask_dir = input_root / 'ISIC2018_Task1_Training_GroundTruth'
    if not image_dir.exists():
        raise FileNotFoundError(f'missing image directory: {image_dir}')
    if not mask_dir.exists():
        raise FileNotFoundError(f'missing mask directory: {mask_dir}')

    image_map: Dict[str, Path] = {}
    for image_path in sorted(image_dir.glob('*')):
        if not image_path.is_file():
            continue
        if image_path.suffix.lower() not in {'.jpg', '.jpeg', '.png'}:
            continue
        image_map[image_path.stem] = image_path

    mask_map: Dict[str, Path] = {}
    for mask_path in sorted(mask_dir.glob('*_segmentation.png')):
        if not mask_path.is_file():
            continue
        sample_id = mask_path.stem.replace('_segmentation', '')
        mask_map[sample_id] = mask_path

    common_ids = sorted(set(image_map).intersection(mask_map))
    if not common_ids:
        raise ValueError('no matching ISIC2018 image/mask pairs found')

    missing_masks = sorted(set(image_map) - set(mask_map))
    missing_images = sorted(set(mask_map) - set(image_map))
    if missing_masks:
        raise ValueError(f'missing masks for image ids: {missing_masks[:5]}')
    if missing_images:
        raise ValueError(f'missing images for mask ids: {missing_images[:5]}')

    return [{'id': sample_id, 'image_path': image_map[sample_id], 'mask_path': mask_map[sample_id]} for sample_id in common_ids]


def split_samples(
    samples: List[Dict[str, Path]],
    train_ratio: float,
    val_ratio: float,
    seed: int,
) -> Dict[str, List[Dict[str, Path]]]:
    shuffled = list(samples)
    random.Random(seed).shuffle(shuffled)
    total = len(shuffled)
    train_count = int(total * train_ratio)
    val_count = int(total * val_ratio)
    test_count = total - train_count - val_count
    if min(train_count, val_count, test_count) <= 0:
        raise ValueError(
            f'split counts must all be positive, got train={train_count}, val={val_count}, test={test_count}'
        )
    return {
        'train': shuffled[:train_count],
        'val': shuffled[train_count:train_count + val_count],
        'test': shuffled[train_count + val_count:],
    }


def export_split(output_dir: Path, split_name: str, samples: List[Dict[str, Path]]) -> Dict[str, object]:
    images_dir = output_dir / split_name / 'images'
    masks_dir = output_dir / split_name / 'masks'
    images_dir.mkdir(parents=True, exist_ok=True)
    masks_dir.mkdir(parents=True, exist_ok=True)

    ids: List[str] = []
    for sample in sorted(samples, key=lambda item: str(item['id'])):
        sample_id = str(sample['id'])
        image_path = Path(sample['image_path'])
        mask_path = Path(sample['mask_path'])
        ids.append(sample_id)
        shutil.copy2(image_path, images_dir / f'{sample_id}{image_path.suffix.lower()}')
        shutil.copy2(mask_path, masks_dir / f'{sample_id}.png')
    return {'count': len(samples), 'ids': ids}


def main() -> None:
    args = parse_args()
    validate_ratios(args.train_ratio, args.val_ratio, args.test_ratio)
    ensure_clean_dir(args.output_dir, overwrite=args.overwrite)

    samples = collect_samples(args.input_root)
    split_map = split_samples(samples, train_ratio=args.train_ratio, val_ratio=args.val_ratio, seed=args.seed)
    summary = {
        'input_root': str(args.input_root),
        'output_dir': str(args.output_dir),
        'seed': int(args.seed),
        'ratios': {
            'train': float(args.train_ratio),
            'val': float(args.val_ratio),
            'test': float(args.test_ratio),
        },
        'total_samples': len(samples),
        'splits': {},
    }

    for split_name in ('train', 'val', 'test'):
        summary['splits'][split_name] = export_split(args.output_dir, split_name, split_map[split_name])

    summary_path = args.output_dir / 'split_summary.json'
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
